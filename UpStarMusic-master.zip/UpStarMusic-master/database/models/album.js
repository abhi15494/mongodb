// Todo: create Album Schema
