// Todo: Create Artist Model
