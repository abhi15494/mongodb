import React from 'react';

const Picker = () => {
  return (
    <div>
      Picker
    </div>
  );
};

export { Picker };
